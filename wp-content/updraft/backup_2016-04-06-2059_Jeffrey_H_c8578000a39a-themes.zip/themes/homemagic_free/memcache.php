<?php 

function magichorizon_memcache_sidebar($memcache_sidebar_id){

			dynamic_sidebar($memcache_sidebar_id);
			
		
 }
	  
 ?>