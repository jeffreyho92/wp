(function($) {
    'use strict';
    var $lang_item = $('#mk-main-navigation > .main-navigation-ul > .menu-item-language');
    $lang_item.addClass('no-mega-menu').css('visibility', 'visible');
    $('#mk-main-navigation .menu-item-language > a').addClass('menu-item-link');
})(jQuery);